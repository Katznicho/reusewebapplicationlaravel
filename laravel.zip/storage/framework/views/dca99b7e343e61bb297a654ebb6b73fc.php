<?php
    use Filament\Support\Facades\FilamentAsset;
    use Rawilk\FilamentPasswordInput\FilamentPasswordInputServiceProvider;

    $css = FilamentAsset::getStyleHref('filament-password-input', package: FilamentPasswordInputServiceProvider::PACKAGE_ID);
?>

data-dispatch="pw-loaded"
x-load-css="[<?php echo \Illuminate\Support\Js::from($css)->toHtml() ?>]"
x-on:pw-loaded-css.window.once="() => {
    if (window.__pwStylesLoaded === true) { return }
    const style = document.head.querySelector('link[href=\'<?php echo e($css); ?>\']');
    style && style.remove();
    style && document.head.prepend(style);
    window.__pwStylesLoaded = true;
}"
<?php /**PATH /home/codeartisan/Desktop/laravelapps/reuse/resources/views/vendor/filament-password-input/partials/load-css.blade.php ENDPATH**/ ?>