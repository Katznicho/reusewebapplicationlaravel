<div class="max-w-7xl mx-auto p-6 lg:p-8">
    <p>You cancelled your payment</p>
</div>