<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Community</title>
</head>

<body>
    <div style="width: 100%; height: 100%">
        <embed id="frPDF" height="1000px" width="100%" src="{{ $documentUrl }}"></embed>
    </div>
</body>

</html>