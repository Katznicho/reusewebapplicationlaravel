<?php

return [
    'user_roles' => [
        'DONOR' => 'DONOR',
        'RECEIVER' => 'RECEIVER',
        'ADMIN' => 'ADMIN',
    ],

];
