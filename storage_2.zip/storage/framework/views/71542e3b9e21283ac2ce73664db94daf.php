<?php echo e($slot); ?>

<?php /**PATH /home/codeartisan/Desktop/laravelapps/reuse/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>